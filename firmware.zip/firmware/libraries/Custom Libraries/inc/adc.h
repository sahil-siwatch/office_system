void init_adc();

float get_battery_voltage();

void uninit_adc();