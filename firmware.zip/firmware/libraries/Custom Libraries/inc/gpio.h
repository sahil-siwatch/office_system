void init_gpio();

void indicate_low_battery();

void init_interrupt_pins();

void hardware_check();

void indicate_charging();

void init_charging_interrupt();