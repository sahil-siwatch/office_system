void init_pwm();

void set_duty_cycle(uint8_t duty_cycle);

void led_on(uint8_t duty);

void led_off();

void toggle_led_pwm();