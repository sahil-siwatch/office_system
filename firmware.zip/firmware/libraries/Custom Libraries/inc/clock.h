void init_clock();

void config_low_power();